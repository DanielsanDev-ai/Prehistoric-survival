package com.prehistoricsurvival.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.prehistoricsurvival.PrehistoricSurvival;
import com.prehistoricsurvival.entity.DilophosaurusEntity;
import com.prehistoricsurvival.entity.EntityAction;
import com.prehistoricsurvival.entity.GrowthStage;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Modelo del Dilophosaurus: cuerpo largo y bajo, cuello curvo, hocico estrecho,
 * dos crestas craneales, brazos pequeños, patas digitigradas y cola segmentada. */
public class DilophosaurusModel extends EntityModel<DilophosaurusEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(PrehistoricSurvival.MOD_ID, "dilophosaurus"), "main");

    private final ModelPart root, adult, baby;
    private final ModelPart neck, head, jaw, tail, legR, legL, armR, armL, frillR, frillL;
    private final ModelPart bHead, bLegR, bLegL, bTail;

    public DilophosaurusModel(ModelPart root) {
        this.root = root;
        adult = root.getChild("adult");
        baby = root.getChild("baby");
        neck = adult.getChild("neck");
        head = neck.getChild("head");
        jaw = head.getChild("jaw");
        tail = adult.getChild("tail");
        legR = adult.getChild("leg_r");
        legL = adult.getChild("leg_l");
        armR = adult.getChild("arm_r");
        armL = adult.getChild("arm_l");
        frillR = adult.getChild("frill_r");
        frillL = adult.getChild("frill_l");
        bHead = baby.getChild("b_head");
        bLegR = baby.getChild("b_leg_r");
        bLegL = baby.getChild("b_leg_l");
        bTail = baby.getChild("b_tail");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition adult = root.addOrReplaceChild("adult", CubeListBuilder.create(), PartPose.ZERO);

        // Torso: pecho profundo y cadera marcada, evitando el aspecto de bloque uniforme.
        adult.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-3.5f, -3.5f, -6f, 7f, 7f, 12f)
                .texOffs(38, 0).addBox(-3.0f, -3.0f, -8f, 6f, 6f, 5f)
                .texOffs(60, 0).addBox(-3.4f, -2.8f, 3f, 6.8f, 5.6f, 5f),
                PartPose.offset(0, 13, 1));

        PartDefinition neck = adult.addOrReplaceChild("neck", CubeListBuilder.create()
                .texOffs(0, 22).addBox(-2.0f, -2.5f, -5.5f, 4f, 5f, 7f)
                .texOffs(24, 22).addBox(-1.6f, -2.0f, -7.0f, 3.2f, 4f, 3f),
                PartPose.offsetAndRotation(0, 11, -5, 0.16f, 0, 0));

        PartDefinition head = neck.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(40, 22).addBox(-2.35f, -2.5f, -3.6f, 4.7f, 4f, 5f)
                .texOffs(60, 22).addBox(-1.55f, -1.65f, -8.0f, 3.1f, 2.6f, 5f)
                .texOffs(78, 22).addBox(-1.2f, -0.8f, -9.0f, 2.4f, 1.5f, 2f),
                PartPose.offset(0, -3.0f, -5.5f));
        head.addOrReplaceChild("jaw", CubeListBuilder.create()
                .texOffs(92, 22).addBox(-1.35f, 0, -7.6f, 2.7f, 1.15f, 7f),
                PartPose.offset(0, 0.7f, 0));
        // Crestas dobles, elevadas y separadas para que se lean claramente desde lejos.
        head.addOrReplaceChild("crest_l", CubeListBuilder.create()
                .texOffs(0, 38).addBox(0.15f, -5.3f, -2.2f, 1.75f, 3.4f, 3.6f)
                .texOffs(12, 38).addBox(0.35f, -6.2f, -1.6f, 1.35f, 1.3f, 2.5f),
                PartPose.ZERO);
        head.addOrReplaceChild("crest_r", CubeListBuilder.create()
                .texOffs(24, 38).addBox(-1.9f, -5.3f, -2.2f, 1.75f, 3.4f, 3.6f)
                .texOffs(36, 38).addBox(-1.7f, -6.2f, -1.6f, 1.35f, 1.3f, 2.5f),
                PartPose.ZERO);
        head.addOrReplaceChild("eye_ridge_l", CubeListBuilder.create().texOffs(48, 38)
                .addBox(1.65f, -2.0f, -3.1f, 0.8f, 1.0f, 1.8f), PartPose.ZERO);
        head.addOrReplaceChild("eye_ridge_r", CubeListBuilder.create().texOffs(54, 38)
                .addBox(-2.45f, -2.0f, -3.1f, 0.8f, 1.0f, 1.8f), PartPose.ZERO);

        // Cola larga en tres volúmenes que afinan progresivamente.
        PartDefinition tail = adult.addOrReplaceChild("tail", CubeListBuilder.create()
                .texOffs(0, 48).addBox(-1.8f, -1.6f, 0, 3.6f, 3.2f, 7f)
                .texOffs(22, 48).addBox(-1.25f, -1.1f, 6.2f, 2.5f, 2.3f, 7f)
                .texOffs(42, 48).addBox(-0.7f, -0.65f, 12.5f, 1.4f, 1.3f, 5.5f),
                PartPose.offset(0, 13, 6));

        // Muslos, tibias y pies con dedos: patas más robustas que los brazos.
        PartDefinition legR = adult.addOrReplaceChild("leg_r", CubeListBuilder.create()
                .texOffs(60, 42).addBox(-1.6f, -0.2f, -1.8f, 3.1f, 4.8f, 3.7f)
                .texOffs(76, 42).addBox(-1.05f, 3.7f, -1.25f, 2.1f, 4.8f, 2.4f)
                .texOffs(88, 42).addBox(-1.7f, 7.8f, -3.0f, 3.4f, 1.1f, 4.6f),
                PartPose.offset(-2.5f, 15.5f, 2.2f));
        PartDefinition legL = adult.addOrReplaceChild("leg_l", CubeListBuilder.create()
                .texOffs(60, 42).addBox(-1.5f, -0.2f, -1.8f, 3.1f, 4.8f, 3.7f)
                .texOffs(76, 42).addBox(-1.05f, 3.7f, -1.25f, 2.1f, 4.8f, 2.4f)
                .texOffs(88, 42).addBox(-1.7f, 7.8f, -3.0f, 3.4f, 1.1f, 4.6f),
                PartPose.offset(2.5f, 15.5f, 2.2f));

        adult.addOrReplaceChild("arm_r", CubeListBuilder.create()
                .texOffs(104, 0).addBox(-0.8f, -0.3f, -1.2f, 1.6f, 3.3f, 2.1f)
                .texOffs(112, 0).addBox(-0.65f, 2.5f, -1.7f, 1.3f, 1.5f, 2.0f),
                PartPose.offset(-3.0f, 11.0f, -3.0f));
        adult.addOrReplaceChild("arm_l", CubeListBuilder.create()
                .texOffs(104, 0).addBox(-0.8f, -0.3f, -1.2f, 1.6f, 3.3f, 2.1f)
                .texOffs(112, 0).addBox(-0.65f, 2.5f, -1.7f, 1.3f, 1.5f, 2.0f),
                PartPose.offset(3.0f, 11.0f, -3.0f));

        // Gola de amenaza estilizada; plegada en reposo y desplegada al intimidar/escupir.
        adult.addOrReplaceChild("frill_r", CubeListBuilder.create()
                .texOffs(96, 10).addBox(-5.1f, -3.4f, -0.45f, 5.0f, 6.6f, 0.8f),
                PartPose.offsetAndRotation(-1.6f, 10.5f, -4.8f, 0, 0, -0.10f));
        adult.addOrReplaceChild("frill_l", CubeListBuilder.create()
                .texOffs(108, 10).addBox(0.1f, -3.4f, -0.45f, 5.0f, 6.6f, 0.8f),
                PartPose.offsetAndRotation(1.6f, 10.5f, -4.8f, 0, 0, 0.10f));

        // Cría con cabeza proporcionalmente grande, patas cortas y cola fina.
        PartDefinition baby = root.addOrReplaceChild("baby", CubeListBuilder.create(), PartPose.ZERO);
        baby.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-2.8f, -2.8f, -4.5f, 5.6f, 5.6f, 9f), PartPose.offset(0, 17, 0));
        baby.addOrReplaceChild("b_head", CubeListBuilder.create().texOffs(40, 22)
                .addBox(-2.1f, -3.4f, -3.2f, 4.2f, 3.7f, 4.6f)
                .texOffs(60, 22).addBox(-1.35f, -2.6f, -6.5f, 2.7f, 2.0f, 3.8f)
                .texOffs(0, 38).addBox(-1.45f, -5.0f, -2.0f, 1.2f, 2.1f, 2.3f)
                .texOffs(24, 38).addBox(0.25f, -5.0f, -2.0f, 1.2f, 2.1f, 2.3f),
                PartPose.offset(0, 14.5f, -3.0f));
        baby.addOrReplaceChild("b_tail", CubeListBuilder.create().texOffs(0, 48)
                .addBox(-0.9f, -0.8f, 0, 1.8f, 1.6f, 9f), PartPose.offset(0, 17, 3));
        baby.addOrReplaceChild("b_leg_r", CubeListBuilder.create().texOffs(60, 42)
                .addBox(-0.9f, 0, -0.8f, 1.8f, 4.5f, 2.0f), PartPose.offset(-1.4f, 19, 0));
        baby.addOrReplaceChild("b_leg_l", CubeListBuilder.create().texOffs(60, 42)
                .addBox(-0.9f, 0, -0.8f, 1.8f, 4.5f, 2.0f), PartPose.offset(1.4f, 19, 0));
        return LayerDefinition.create(mesh, 128, 64);
    }

    @Override
    public void setupAnim(DilophosaurusEntity entity, float limbSwing, float limbSwingAmount,
                          float age, float netHeadYaw, float headPitch) {
        boolean isBaby = entity.getStage() == GrowthStage.BABY;
        adult.visible = !isBaby;
        baby.visible = isBaby;
        boolean spitting = entity.getAction() == EntityAction.SPITTING;
        boolean threat = entity.isAggressive() || entity.getAction() == EntityAction.THREAT || spitting;
        float s = limbSwing * 0.6662f;
        float amount = limbSwingAmount;

        if (isBaby) {
            bLegR.xRot = Mth.cos(s) * 1.0f * amount;
            bLegL.xRot = Mth.cos(s + Mth.PI) * 1.0f * amount;
            bTail.yRot = Mth.sin(s) * 0.24f * amount;
            bHead.xRot = Mth.clamp(headPitch, -30f, 30f) * Mth.DEG_TO_RAD;
            return;
        }

        float flare = threat ? (spitting ? 1.0f : 0.82f) : 0.04f;
        frillR.zRot = Mth.lerp(0.22f, frillR.zRot, -flare);
        frillL.zRot = Mth.lerp(0.22f, frillL.zRot, flare);
        legR.xRot = Mth.cos(s) * 1.05f * amount;
        legL.xRot = Mth.cos(s + Mth.PI) * 1.05f * amount;
        armR.xRot = -0.38f + Mth.sin(age * 0.08f) * 0.035f;
        armL.xRot = armR.xRot;
        tail.yRot = Mth.sin(s) * 0.22f * amount + Mth.sin(age * 0.055f) * 0.035f;
        neck.xRot = threat ? 0.25f : 0.10f + Mth.cos(s * 2f) * 0.035f * amount;
        head.xRot = headPitch * Mth.DEG_TO_RAD + (threat ? -0.10f : 0f);
        head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        jaw.xRot = spitting ? 0.62f : (threat ? 0.32f + Mth.sin(age * 0.30f) * 0.06f : 0f);
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
