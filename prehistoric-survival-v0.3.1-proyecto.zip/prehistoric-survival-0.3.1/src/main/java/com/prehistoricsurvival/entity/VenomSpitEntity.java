package com.prehistoricsurvival.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** Proyectil de veneno del Dilophosaurus: ralentiza y ciega brevemente al objetivo. */
public class VenomSpitEntity extends ThrowableItemProjectile {
    public VenomSpitEntity(EntityType<? extends VenomSpitEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected Item getDefaultItem() {
        // La bola de slime funciona como representación visual; los efectos son propios del proyectil.
        return Items.SLIME_BALL;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            level().addParticle(ParticleTypes.COMPOSTER, getX(), getY(), getZ(), 0.0, 0.015, 0.0);
            level().addParticle(ParticleTypes.HAPPY_VILLAGER, getX(), getY(), getZ(), 0.0, 0.0, 0.0);
        } else if (tickCount > 50) {
            discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity hit = result.getEntity();
        if (hit instanceof LivingEntity living && hit != getOwner()) {
            living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
            living.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
            living.hurt(damageSources().mobProjectile(this, getOwner()), 2.0f);
        }
        if (!level().isClientSide) {
            ((net.minecraft.server.level.ServerLevel) level()).sendParticles(
                    ParticleTypes.COMPOSTER, getX(), getY(), getZ(), 12, 0.18, 0.18, 0.18, 0.04);
        }
        discard();
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide) discard();
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
    }

    @Override
    public ItemStack getItem() {
        return new ItemStack(getDefaultItem());
    }
}
