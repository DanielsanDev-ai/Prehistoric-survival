# Revisión técnica — Prehistoric Survival v0.3.1

## Cambios aplicados
- Se corrigió `DinoEggBlock.canSurvive`: ahora acepta el bloque `NEST` como soporte válido, conservando el sistema de incubación del huevo colocado encima del nido.
- Se rediseñó la geometría del Dilophosaurus y se reemplazaron sus texturas de variante.
- Los eventos de sonido del Dilophosaurus apuntan a archivos propios bajo `sounds/dilophosaurus/`.
- Se redujo la dificultad de domesticación del Dilo y se añadió feedback visible del porcentaje de vínculo.
- Se amplió el rango de lanzamiento del veneno, se usa el sonido de ataque al disparar y el Dilo busca presas con hambre inferior al 90%.

## Compatibilidad objetivo
- Minecraft Java 1.20.1
- Forge 47.3.0
- Java 17

## Verificación pendiente
Este paquete contiene código fuente y recursos. En este entorno no está instalado Gradle y no se pudo ejecutar `gradle build`; por tanto, no se afirma que el JAR esté compilado ni que la sesión dentro de Minecraft haya sido probada. Ejecuta el workflow de GitHub Actions para comprobar la compilación y después prueba el JAR en el juego.
