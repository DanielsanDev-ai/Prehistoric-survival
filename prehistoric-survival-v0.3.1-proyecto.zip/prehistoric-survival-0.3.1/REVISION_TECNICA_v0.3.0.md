# Revisión técnica — Prehistoric Survival v0.3.0

## Base y compatibilidad
- Minecraft Java 1.20.1
- Forge 47.3.0
- Java 17
- Se conserva el workflow `.github/workflows/build.yml`.
- Se mantienen las entidades Dodo, Velociraptor y Tyrannosaurus rex y la base común de guardado, domesticación, seguimiento, crecimiento, reproducción, nidos, incubación y eclosión.

## Comprobaciones realizadas en este entorno
- 55 archivos JSON parsean correctamente.
- Las texturas de portada del libro y del Dilophosaurus referenciadas existen.
- 52 archivos Java revisados con comprobación léxica básica de llaves, paréntesis y corchetes: sin desbalances.
- La nueva clase `VenomSpitEntity` está registrada y tiene renderer.
- Los textos ES/EN incluyen el proyectil venenoso.

## Pendiente de verificación real
- No se pudo ejecutar `gradle build`: Gradle no está instalado en el entorno y la conexión de red está deshabilitada, así que no fue posible descargar la distribución ni las dependencias Forge.
- Debe confirmarse la compilación en GitHub Actions y después probar el JAR en Minecraft 1.20.1 + Forge 47.3.0.
- No se han medido rendimiento ni equilibrio en una sesión real.

## Limitaciones conocidas
- Las nuevas páginas futuras se agregan registrándolas en `GuideBookPages.register(...)`; no se autogeneran por reflexión al añadir una entidad.
- El modelo del Dilophosaurus tiene geometría infantil y adulta; el adolescente utiliza el modelo adulto a escala intermedia.
- Los sonidos del Dilophosaurus reutilizan recursos de sonido existentes temporalmente.
